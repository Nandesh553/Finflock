package com.example.QuartzExample;

import java.time.LocalDate;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;

import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.ui.Button;
import com.vaadin.ui.DateField;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.themes.ValoTheme;

@SuppressWarnings("serial")
public class TimeForm extends FormLayout {
//	private final static Logger LOGGER = Logger.getLogger(TimeForm.class.getName());
	
	// Create a DateField with the default style
	private DateField date = new DateField();
//	private TimeTextField timeStore = new TimeTextField("Normal 12h");
	private Button createJobButton = new Button("Create Job");

	public String getDescription() {
//		LOGGER.log(Level.INFO, "Returning Description");
		return "Date Form";
	}

	public TimeForm() {
		
		// Set the date to present
		date.setValue(LocalDate.now());

		setSizeUndefined();
//		addComponents(date, timeStore, createJobButton);
		addComponents(date, createJobButton);
//		LOGGER.log(Level.INFO, "Button and Date added");

		createJobButton.setStyleName(ValoTheme.BUTTON_PRIMARY);
		createJobButton.setClickShortcut(KeyCode.ENTER);

		// binder.bindInstanceFields(this);

		createJobButton.addClickListener(e -> {
			try {
				this.saveJob();
			} catch (SchedulerException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		});
//		LOGGER.log(Level.INFO, "Returning Form Object");
	}

	private void saveJob() throws SchedulerException {
		//TODO save to RDBMS
		String savedDate = date.getValue().toString();
//		LOGGER.log(Level.INFO, "Current Date : "+savedDate );
		
		JobDetail jdt = JobBuilder.newJob(HelloJob.class).build();
		Trigger t2 = TriggerBuilder.newTrigger().withIdentity("Some Really Other Trigger")
				.withSchedule(SimpleScheduleBuilder.simpleSchedule().repeatForever().withIntervalInSeconds(10)).build();
		Scheduler sc = new StdSchedulerFactory("quartz.properties").getScheduler();

		sc.start();
		sc.scheduleJob(jdt, t2);
		return;
	}


}
