package com.example.QuartzExample;

import java.util.Date;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;


public class HelloJob implements Job{
	private final static Logger LOGGER = Logger.getLogger(HelloJob.class.getName());
	
	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		// TODO Auto-generated method stub
		LOGGER.log(Level.INFO, "Just doing my job" + new Date().toString());
	}

}
