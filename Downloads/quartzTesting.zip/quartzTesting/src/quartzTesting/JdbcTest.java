package quartzTesting;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class JdbcTest {

	public static void main(String[] args) {
		//String user = "ISO-1\\g_nan";
		String user = "SA";
		String pwd = "root";

		String url = "jdbc:sqlserver://localhost;databaseName=test;";

        try {
        	System.out.println("In try");
    		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
    		Connection conn = DriverManager.getConnection(url, user, pwd);

    		System.out.println("connected \n");

            Statement statement = conn.createStatement();
            String queryString = "select Name from sys.Databases";
            ResultSet rs = statement.executeQuery(queryString);
            while (rs.next()) {
                System.out.println(rs.getString(1));
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
	}
}